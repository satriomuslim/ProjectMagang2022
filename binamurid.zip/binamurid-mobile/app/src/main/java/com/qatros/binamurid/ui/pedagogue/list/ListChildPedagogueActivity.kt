package com.qatros.binamurid.ui.pedagogue.list

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.qatros.binamurid.R

class ListChildPedagogueActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_child_pedagogue)
    }
}
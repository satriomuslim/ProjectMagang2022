package com.qatros.binamurid.data.local.dao

import androidx.room.Dao

@Dao
interface ExampleDao {
}
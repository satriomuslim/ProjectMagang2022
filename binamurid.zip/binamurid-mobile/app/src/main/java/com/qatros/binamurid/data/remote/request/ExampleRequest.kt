package com.qatros.binamurid.data.remote.request

class ExampleRequest {
}
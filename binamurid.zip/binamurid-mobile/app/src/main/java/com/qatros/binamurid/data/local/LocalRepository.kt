package com.qatros.binamurid.data.local

class LocalRepository(private val localDataBase : LocalDatabase) {
}
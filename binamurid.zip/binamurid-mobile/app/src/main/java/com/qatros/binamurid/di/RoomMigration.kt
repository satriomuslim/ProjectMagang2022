package com.qatros.binamurid.di

class RoomMigration {
}
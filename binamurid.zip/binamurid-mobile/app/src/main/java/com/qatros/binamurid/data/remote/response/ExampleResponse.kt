package com.qatros.binamurid.data.remote.response

class ExampleResponse {
}
package com.qatros.binamurid.base

import androidx.fragment.app.Fragment

abstract class BaseFragment: Fragment() {
}